import React, { useState } from "react";
import Background_Img from "../../component/Background_Img/Background_Img";
import Footer from "../../component/Footer/Footer";
import Card from "../../component/Card/Card";
import Sidebar, { SidebarMobile } from "../../component/Sidebar/Sidebar";
import "./Admin.css"
const Admin = () => {
  const [SidebarStatus, setSidebarStatus] = useState(false)

  return (
    <>

      <Background_Img

        header="As An Admin" />

      <hr />

      <div className="p-3">
        <div className={`flex duration-300 overflow-hidden`}>
          <div className="shrink-0 hidden  md:static md:flex">
            <Sidebar amarSideStatus={SidebarStatus} setSidebarStatus={setSidebarStatus} />
          </div>

          <SidebarMobile amarSideStatus={SidebarStatus} setSidebarStatus={setSidebarStatus} />

          <div className={`w-full`}>
            {/* <div className="s">
              <div className="row gap-6 md:gap-0">
                <div className="col-lg-3">
                  <Card />
                </div>

                <div className="col-lg-3">
                  <Card />
                </div>
                <div className="col-lg-3">
                  <Card />
                </div>
                <div className="col-lg-3">
                  <Card />
                </div>
              </div>
            </div> */}
            <button className="clickMeBtn" onClick={() => setSidebarStatus(!SidebarStatus)} >click me</button>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-0">

              {
                [...new Array(8)].map(item =>

                  <div className="shrink-0">
                    <Card />
                  </div>
                )
              }
            </div>

            {/* <div className="s pt-5">
              <div className="row">
                <div className="col-lg-3">
                  <Card />
                </div>

                <div className="col-lg-3">
                  <Card />
                </div>
                <div className="col-lg-3">
                  <Card />
                </div>
                <div className="col-lg-3">
                  <Card />
                </div>
              </div>
            </div> */}
          </div>
        </div>
      </div>



      <hr />
      <Footer />

    </>
  );
};

export default Admin;
