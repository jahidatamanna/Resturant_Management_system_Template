import React from "react";
import { NavLink } from "react-router-dom";
// import Navbar from "../../component/Navbar/Navbar";
import Navbar from "../../component/Navbar/Navbar";
import Footer from "../../component/Footer/Footer";
import Para from "../../component/Para/Para";
import Single_picture from "../../component/Single_Picture/Single_picture";
//import Single_pic_desc from "../../component/Single_pic_desc/Single_pic_desc";
import Single_Slider from "../../component/Single_Slider/Single_Slider";
import Multiple_Slider from "../../component/Multiple_Slider/Multiple_Slider";
import Single_pic_desc from "../../component/Single_pic_desc/Single_pic_desc";

const Home = () => {
  return (
    <>
      <Navbar />
      <hr />

      <Single_Slider />

      <hr />

      <Para
        title="TASTY AND CRUNCHY"
        subtitle="Our Specialties"
        describe="We collect the best quality of ingredients From market. With the best execution we provide our guest fresh & very Delicious Food. Exceptional Service of our Staffs we maintained our standard as one of the most prominent fine dining restaurant in Dhaka city."
      />

      <hr />

      <div class="container  ">
        <div className="row ">
          <div className="col-lg-4 col-sm-12 p-1">
            <div class="card bg-dark   ">
              <Single_picture photo="https://imgix.theurbanlist.com/content/article/306326063_1275798086579034_3708037250313031170_n.jpg?auto=format,compress&w=520&h=390&fit=crop" />
            </div>
          </div>

          <div className="col-lg-4 col-sm-12 p-1">
            <div class="card bg-dark   ">
              <Single_picture photo="https://imgix.theurbanlist.com/content/article/306326063_1275798086579034_3708037250313031170_n.jpg?auto=format,compress&w=520&h=390&fit=crop" />
            </div>
          </div>

          {/* <div className="col-lg-4 col-sm-12 ">
            <div class="card  m-1 bg-dark ">
              <Single_picture photo="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2018/10/4/1/FN_chain-restaurant-entrees_Applebees_Bourbon-Street-Chicken-Shrimp_s6x4.jpg.rend.hgtvcom.616.411.suffix/1538685780055.jpeg" />
            </div>
          </div>
          

          <div className="col-lg-4 col-sm-12">
            <div class="card bg-dark  m-1  ">
              <Single_picture photo="https://media-cdn.tripadvisor.com/media/photo-s/1c/33/34/e9/oven-baked-veal-ribs.jpg" />
            </div>
          </div> */}

          <div className="col-lg-4 col-sm-12 p-1">
            <div class="card bg-dark    ">
              <Single_picture photo="https://imgix.theurbanlist.com/content/article/306326063_1275798086579034_3708037250313031170_n.jpg?auto=format,compress&w=520&h=390&fit=crop" />
            </div>
          </div>
        </div>
      </div>
      <hr />

      <div className="container">
        <div className="row">
          <div className="col-lg-6 col-sm-12">
            <Single_picture photo="https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Hamburger_%28black_bg%29.jpg/640px-Hamburger_%28black_bg%29.jpg" />
          </div>
          <div className="col-lg-6 col-sm-12">
            <Single_pic_desc
              title1="TASTY AND CRUNCHY"
              title2=" Chicken Pizza"
              para="This is so happening. Getting dinner on the table has never been easier. One pan meals are my absolute favorite kind of meals because they usual mean simplicity, minimal clean-up, and less stress"
            />
          </div>
        </div>
      </div>
      <hr />

      <div className="container">
        <div className="row">
          <div className="col-lg-6 col-sm-12">
            <Single_pic_desc
              title1="TASTY AND CRUNCHY"
              title2=" Burger & French Fry"
              para="This is so happening. Getting dinner on the table has never been easier. One pan meals are my absolute favorite kind of meals because they usual mean simplicity, minimal clean-up, and less stress"
            />
          </div>
          <div className="col-lg-6 col-sm-12">
            <Single_picture photo="https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Pizza-3007395.jpg/1200px-Pizza-3007395.jpg" />
          </div>
        </div>
      </div>
      <hr />

      <Multiple_Slider />

      <hr />
      <Para
        title="TASTY AND CRUNCHY"
        subtitle="Book a Table"
        describe="To book a table in advance please call on our hotline below
      01797012163, 01797012175."
      />
      <hr />
      <Footer />
    </>
  );
};

export default Home;
