import React from "react";
import Background_Img from "../../component/Background_Img/Background_Img";
import Background_Img_des from "../../component/Background_Img/Background_Img_des";

const Customer = () => {
  return (
    <>
      <Background_Img header="I am Customer" />

<div className="container m-2">
    <div className="row">
        <div className="col-sm-12 col-lg-4">4</div>
        <div className="col-sm-12 col-lg-8">8</div>
    </div>
</div>

    </>
  );
};

export default Customer;
