import React from 'react'
import "./Single_picture.css"
const Single_picture = ({photo}) => {
  return (
    <>
    
    <div className="pic py-3 px-3  text-center">

<img src={photo} alt=""    />

</div>
    
    
    </>
  )
}

export default Single_picture