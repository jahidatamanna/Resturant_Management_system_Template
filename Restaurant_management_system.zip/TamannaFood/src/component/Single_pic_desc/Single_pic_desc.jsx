import React from 'react'
import "./Single_Pic_Desc.scss";
const Single_pic_desc = ({title1,title2,para}) => {
  return (
    <>
    
    <div className="container">
       
         
          <div className="Dish_Details p-5">
            <h3> {title1}</h3>
            <h2>{title2}</h2>
            <p>{para}</p>
            {/* <Link to="" className="btn btn-dark text-light">VIEW OUR RECIPE</Link> */}
<a className="btn btn-dark text-light  " href="">view our menu</a>
          </div>
        </div>
    
    
    
    
    </>
  )
}

export default Single_pic_desc