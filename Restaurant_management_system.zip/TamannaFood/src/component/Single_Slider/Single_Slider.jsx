import React from "react";
import "swiper/css";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper";
import "swiper/css/autoplay";
import "swiper/css/pagination";
const Single_Slider = () => {
  return (
    <>
      <Swiper
        spaceBetween={0}
        slidesPerView={1}
        loop={true}
        autoplay={{
          delay: 3000,
        }}
        modules={[Autoplay, Pagination]}
        pagination={{ clickable: true }}
      >
        <SwiperSlide>
          <div className="box">
            <div
              className="innerbox"
              style={{
                height: "400px",
                width: "100%",
                background:
                  "url(" +
                  "https://imgmedia.lbb.in/media/2023/01/63d37aa371710d3f45ec1fa8_1674803875414.jpg" +
                  ")",
              }}
            ></div>
          </div>
        </SwiperSlide>

        <SwiperSlide>
          <img
            style={{ height: "400px", width: "100%" }}
            src="https://resizer.otstatic.com/v2/photos/wide-huge/1/25166454.jpg"
            alt=""
          />
        </SwiperSlide>
        <SwiperSlide>
          <div className="box">
            <img
              style={{ height: "400px", width: "100%" }}
              src="https://www.liveriga.com/userfiles/images/apmekle/est-dzert/gardezu-restorani/vincents/vincentsinterjers.jpeg?w=780&mode=3%3A2%7Ccrop&s=7f5f0f591d7762423bf8271f3b035366"
              alt=""
            />
          </div>
        </SwiperSlide>
        <SwiperSlide>
          <img
            style={{ height: "400px", width: "100%" }}
            src="https://media.timeout.com/images/105918969/image.jpg"
            alt=""
          />
        </SwiperSlide>
       
      </Swiper>
    </>
  );
};

export default Single_Slider;
