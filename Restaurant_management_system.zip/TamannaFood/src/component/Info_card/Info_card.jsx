import React from "react";

const Info_card = () => {
  return
   <>
   
   I am Info Card.
   I am Info Card. 
   I am Info Card.

   </>;
};

export default Info_card;
