import React from "react";
import "./Card.css"
const Card = () => {
  return (
    <>
      <div className="container ">
        <div className="card h-50 w-120 ">
          <div className="box text-center   py-2 bg-dark">
            <img
              src="https://www.kylinseating.in/uploads/pf/restaurant-furniture/big-restaurant-chair-table-set.jpg"
              alt=""
            />

          </div>

          <div className="card-body text-center ">
            <h5 className="card-title ">
              {" "}
              <b>Customers order details </b>
            </h5>
          </div>
          <div className="pb-3 text-center text-light">
            <button type="button" className="btn btn-dark text-light">
              See More
            </button>
          </div>
        </div>
      </div>


    </>
  );
};

export default Card;


export const FoodCard = ({ setCount }) => {
  return (

    <div class="food-card">
      <img className="mx-auto w-[150px]" src="https://img.freepik.com/premium-photo/bargar-fast-food-image-ai-generated_812649-412.jpg?w=100" alt="Food Image" />
      <h2>Delicious Food</h2>
      <p>A description of the food goes here.</p>
      <p>Price: $10</p>
      <button onClick={() => setCount(p => p + 1)}>Add to Cart</button>
    </div>
  )
}