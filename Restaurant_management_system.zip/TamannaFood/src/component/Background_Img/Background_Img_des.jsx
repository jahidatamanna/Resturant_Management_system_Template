import React from 'react'

const Background_Img_des = ({ header }) => {
  return (
   <>
   
   
   <div className="container">
    <div className="background_img_des text-center pt-5">
        
        <h2>{header}</h2>
       <button>Back To Home</button>
      </div>
    </div>
   
   
   </>
  )
}

export default Background_Img_des