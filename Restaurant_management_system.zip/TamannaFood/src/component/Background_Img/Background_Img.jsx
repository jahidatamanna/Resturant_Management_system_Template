import React from "react";
import Background_Img_des from "./Background_Img_des";

const Background_Img = ({ header }) => {
  return (
    <>
      <div className="Background_img ">
        <div
          style={{
            height: "300px",
            backgroundImage: `url("https://englishlive.ef.com/blog/wp-content/uploads/sites/2/2015/06/food-salad-restaurant-person-1024x710.jpg")`,
          }}
        >
          <div className="p-5 text-center  ">
            <div className="pt-5 my-5">
              <h2>{header}</h2>

              <a href="/" className="btn btn-light  mb-4   text-dark ">Back To Home</a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Background_Img;
