import React, { useState } from 'react'
import Background_Img from '../Background_Img/Background_Img'
import { FoodCard } from '../Card/Card'
import { BiCart } from 'react-icons/bi'
import { MdClose } from 'react-icons/md'

const Indian_Food = () => {
  const [count, setCount] = useState(0)
  return (
    <>

      <Background_Img />
      <hr />

      <div class="container ">
        <div class="row  ">
          <div class="col-lg-5 col-sm-12 pt-4 m-2">

            <select class="form-select" id="validationCustom04" required>
              <option selected disabled value="">Default Sorting</option>
              <option>Sort by popularity</option>
              <option>Sort by latest</option>
              <option>Sort by average rating</option>
              <option>Sort by price : low to high</option>
              <option>Sort by price : high to low </option>
            </select>
            {/* <div class="invalid-feedback"> */}
          </div>
          <div class="col-lg-5 col-sm-12 pt-4 m-2">
          </div>
        </div>

      </div>

      <hr />
      <div className="container">
        <div className="">

          <div className="floatingButton cursor-pointer fixed right-0 top-1/2 -translate-y-1/2">
            <div className="box group text-center flex flex-col  py-3 px-4 bg-slate-200 rounded text-[20px]">
              <button className="cart group-hover:hidden">
                <BiCart />
              </button>
              <button onClick={() => setCount(0)} className="close hidden group-hover:block">
                <MdClose className='text-rose-500'/>
              </button>
              <span className='text-[13px] font-Montserrat'>{(count < 9 ? '0' + '' + count : count)}</span>

            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">

            {
              [...new Array(10)].map(item =>
                <FoodCard setCount={setCount} />
              )
            }

          </div>
        </div>
      </div>

      <hr />
      <div class="py-3 ">
        <ul class="pagination  justify-content-center    ">
          <li class="page-item "> <a class="page-link text-dark" href="#">Previous...</a></li>
          <li class="page-item "> <a class="page-link text-dark " href="#">1</a></li>
          <li class="page-item"> <a class="page-link text-dark" href="#">2</a></li>
          <li class="page-item"> <a class="page-link text-dark " href="#">3</a></li>

          <li class="page-item"> <a class="page-link text-dark " href="#">Next..</a></li>
        </ul>
      </div>


    </>
  )
}

export default Indian_Food