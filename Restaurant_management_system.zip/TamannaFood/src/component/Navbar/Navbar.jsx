import { AnimatePresence, motion } from 'framer-motion'
import React, { useState } from 'react'
import { BiHappy, BiMenu } from "react-icons/bi"
import { Link, NavLink } from 'react-router-dom'
const Navbar = () => {

    const navList = [

        {
            title: "Home",
            path: "/",
            dropdown: false
        },
        {
            title: "About",
            path: "/about",
            dropdown: false
        },
        {
            title: "Menu",
            path: "",
            dropdown: true,
            dropdownList: [
                { title: "Indian", path: "/indian-food" },
                { title: "Thai", path: "/coming-soon" },
                { title: "Bangla", path: "/error-page" },
                { title: "Dessert", path: "/desert" },

            ]
        },
        {
            title: "Cart",
            path: "",
            dropdown: true,
            dropdownList: [
                { title: "Login", path: "/login" },
                { title: "Registration", path: "/registration" },


            ]
        },
        {
            title: "Contact",
            path: "/contact",
            dropdown: false
        },
    ]


    // stats

    const [mobileMenuStatus, setMobileMenuStatus] = useState(false)
    const [dropdownActiveIndex, setDropdownActiveIndex] = useState(0)
    return (
        <nav>
            <div className="mobile-nav lg:hidden">
                <div className="nav-header h-[66px] bg-orange-400 flex justify-between items-center">
                    <div className="logo">
                        <h1 className='text-[28px]  font-Montserrat flex gap-3 items-center '>
                            {/* <BiHappy /> */}
                            <img src="https://cdn4.vectorstock.com/i/1000x1000/77/48/funny-chef-restaurant-or-cafe-logo-vector-27107748.jpg" alt="" width="50" height="50"  className="rounded-circle"/>
                            <span className="text-white">Welcom To Our Restaurant</span>
                        </h1>
                    </div>
                    <div className="mobilemenu-icon text-[24px]">
                        <button onClick={() => setMobileMenuStatus(!mobileMenuStatus)} className='text-white px-2 py-2'>
                            <BiMenu />
                        </button>
                    </div>
                </div>

                <AnimatePresence>

                    {
                        mobileMenuStatus && (
                            <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} transition={{ duration: 0.4 }} style={{ overflow: "clip" }}>

                                <div className="mobile-menu bg-blue-400 font-Montserrat">
                                    <ul>

                                        {

                                            navList.map((item, index) =>
                                                item.dropdown ?
                                                    <div className="dropdown">
                                                        <li onClick={() => { dropdownActiveIndex === (index + 1) ? setDropdownActiveIndex(0) : setDropdownActiveIndex(index + 1) }} className='dropdown-btn py-2 flex justify-between cursor-pointer  border-b border-blue-500 px-4'>
                                                            <NavLink to={item.path}>{item.title}</NavLink>
                                                            <span className='text-[18px]'>+</span>

                                                        </li>
                                                        <AnimatePresence>

                                                            {
                                                                (dropdownActiveIndex === (index + 1)) &&
                                                                (
                                                                    <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} transition={{ duration: 0.4 }} style={{ overflow: "clip" }}>
                                                                        <ul className="dropdown-body pl-[40px]">


                                                                            {
                                                                                item.dropdownList.map(dropdownItem =>
                                                                                    <li className='py-2 border-b border-blue-500 cursor-pointer px-4'>
                                                                                        <NavLink to={dropdownItem.path}>{dropdownItem.title}</NavLink>
                                                                                    </li>
                                                                                )
                                                                            }

                                                                        </ul>
                                                                    </motion.div>

                                                                )
                                                            }
                                                        </AnimatePresence>
                                                    </div>

                                                    :
                                                    <li className='py-2 border-b border-blue-500 cursor-pointer px-4'>
                                                        <NavLink to={item.path}>{item.title}</NavLink>
                                                    </li>

                                            )
                                        }


                                    </ul>
                                </div>
                            </motion.div>
                        )
                    }
                </AnimatePresence>
            </div>

            <div className="desktop-nav hidden lg:block">
                <div className="nav-header h-[86px] bg-orange-400 flex justify-between items-center">
                    <div className="logo">
                        <h1 className='text-[28px]  font-Montserrat flex gap-3 items-center p-2  '>
                            {/* <BiHappy /> */}
                             <img src="https://cdn4.vectorstock.com/i/1000x1000/77/48/funny-chef-restaurant-or-cafe-logo-vector-27107748.jpg" alt="" width="50" height="50"  className="rounded-circle"/>

                            <span className="text-white">Welcome to our restaurant</span>
                        </h1>
                    </div>

                    <ul className="right m-0 flex gap-2 items-center font-Montserrat text-[18px]">
                        {/* <li className='px-4'>
                            <NavLink to="/">Home</NavLink>
                        </li> */}
                        {

                            navList.map(item =>
                                item.dropdown ?
                                    <div className="my-dropdown-item relative">
                                        <li className='my-dropdown-btn px-4 '>
                                            <Link className={"nav-link"} to={item.path}>{item.title}</Link>
                                        </li>
                                        <div className="my-dropdown-menu flex flex-col px-4 gap-2  absolute top-full left-0 bg-rose-500 py-8 w-[200px]">
                                            {
                                                item.dropdownList.map(dropItem =>
                                                    <NavLink to={dropItem.path}>{dropItem.title}</NavLink>
                                                )
                                            }

                                        </div>
                                    </div>
                                    :
                                    <li className='px-4'>
                                        <NavLink className={"nav-link"} to={item.path}>{item.title}</NavLink>
                                    </li>
                            )
                        }

                    </ul>

                </div>
            </div>



        </nav>
    )
}

export default Navbar