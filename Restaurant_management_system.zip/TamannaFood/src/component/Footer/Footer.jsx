import React from 'react'
import "./Footer.scss";


const Footer = () => {
  return (
    <>
     <div className="Footer ">
      <div className="container">
        <div className="row  text-light  ">
          <div className="col-lg-12 col-sm-12  ">
            <img
              src="https://img.freepik.com/free-vector/detailed-chef-logo-template_23-2148987940.jpg?w=740&t=st=1686494196~exp=1686494796~hmac=d5e2d9364c26828b8e00df3f32f578c577c694c42cea7676e3dcad6f9aeb90b5"
              className="rounded-circle mx-auto "
              width="100"
              height="100"
              alt=""
            />
            <h4 className='py-2'>
              Visit our exclusive restaurent for once then it will be your
              regular destination for party and celebration.{" "}
            </h4>

            <p>
              <i className="fa-solid fa-location-dot  "></i>&nbsp;408/1, Banasree,
              Rampura, Dhaka 1219, Bangladesh
            </p>
            <p>
             
              <i className="fa-solid fa-envelope"></i>&nbsp; cgprincipal@ymail.com{" "}
            </p>
            <p>
              <i className="fa fa-phone" aria-hidden="true"></i>&nbsp;02-9666058{" "}
            </p>
          </div>



<div className="icons">
<i className='bx bxl-facebook-circle'></i>
<i className='bx bxl-linkedin-square' ></i>
<i className='bx bxl-instagram' ></i>
<i className='bx bxl-twitter' ></i>
<i className='bx bxl-youtube'></i>
</div>

        </div>
      </div>
      </div>
    
    
    </>
  )
}

export default Footer