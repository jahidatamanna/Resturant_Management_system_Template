import React from 'react'
import "./Para.scss";
const Para = ({ title, subtitle, describe }) => {
  return (
   <>
   
   <div className="container text-center">
    <div className="para">
        <h4>{title}</h4>
        <h2>{subtitle}</h2>
        <p>{describe}</p>
      </div>
    </div>
   
   
   </>
  )
}

export default Para