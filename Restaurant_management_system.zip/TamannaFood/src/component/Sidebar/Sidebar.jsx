import React from 'react'
import './Sidebar.css'

import { MdClose } from "react-icons/md"
import { Link } from 'react-router-dom'
const Sidebar = ({ amarSideStatus, setSidebarStatus }) => {


  return (

    <div className={`Sidebar  ${amarSideStatus ? 'ActiveSidebar' : ''}`}>
      <div className="sidebarWrapper">
        <button onClick={() => setSidebarStatus(false)} className='close-btn'>
          <MdClose />
        </button>
        <SidebarMenus />

      </div>

    </div>
  )
}

export default Sidebar


export const SidebarMobile = ({ amarSideStatus, setSidebarStatus }) => {
  return (
    <div className={`MobileSidebar md:hidden  ${amarSideStatus ? 'MobileActiveSidebar' : ''}`}>
      <div className="sidebarWrapper">
        <button onClick={() => setSidebarStatus(false)} className='close-btn'>
          <MdClose />
        </button>

        <SidebarMenus />


      </div>

    </div>
  )
}
export const SidebarMenus = () => {

  const sidebarMenuList = [
    "Display", "Order List", "Chat", "Menu", "Settings"
  ]
  return (
    <ul className="sidebarMenus flex flex-col gap-2 pr-[30px] pt-[50px]">
      {sidebarMenuList.map(item =>
        <li className='py-2 px-2 text-white bg-orange-500 text-lg'>
          <Link className='text-decoration-none whitespace-nowrap overflow-hidden text-white' to={""}>
            {item}
          </Link>
        </li>)}
    </ul>
  )
}

