import React from 'react'
import Background_Img from '../Background_Img/Background_Img'
import Footer from '../Footer/Footer'
import './Login.css'
import { Link } from 'react-router-dom'
const Login = () => {
  return (
   <>
   
   <Background_Img/>


   <div className="container py-3">
 <div className="form ">
          <div className="form-body">
             
              
              <div className="email">
                  <label className="form__label" for="email">Email </label>
                  <input  type="email" id="email" className="form__input" placeholder="Email"/>
              </div>
              <div className="password">
                  <label className="form__label" for="password">Password </label>
                  <input className="form__input" type="password"  id="password" placeholder="Password"/>
              </div>
            
          </div>
          <div class="footer bg-light ">
            
              <button type="submit" class="btn">Login</button>
          </div>
          <div class="p-3 text-center" >
          <button type="button" class="btn btn-light">Forgot Password ?</button> &nbsp;
          <Link to="/admin"  type="button" class="btn btn-light">AS an Admin</Link>

          </div>
      </div>   
         
  
  </div> 


   <Footer/>
   
   
   </>
  )
}

export default Login