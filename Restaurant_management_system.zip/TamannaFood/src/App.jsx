import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Navbar from './component/Navbar/Navbar'
import Home from './Pages/Home/Home'
import Footer from './component/Footer/Footer'
import Single_Slider from './component/Single_Slider/Single_Slider'
import Multiple_Slider from './component/Multiple_Slider/Multiple_Slider'
import Background_Img from './component/Background_Img/Background_Img'
import Background_Img_des from './component/Background_Img/Background_Img_des'
import Customer from './Pages/Customer/Customer'
import Info_card from './component/Info_card/Info_card'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Login from './component/Login/Login'
import Registration from './component/Registration/Registration'
import Admin from './Pages/Admin/Admin'
import Card from './component/Card/Card'
import Indian_Food from './component/Indian_Food/Indian_Food'

function App() {
  const [count, setCount] = useState(0)

  return (

    <>


      {/* <Indian_Food/> */}
      {/* <Admin/> */}
      {/* <Card/> */}



      {/* <Registration/> */}
      {/* <Login/> */}

      <BrowserRouter>


        <Routes>

          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/registration" element={<Registration />} />
          <Route path="/login" element={<Login />} />
          <Route path="/admin" element={<Admin />} />

          <Route path="/customer" element={<Customer />} />
          <Route path="/indian-food" element={<Indian_Food />} />




        </Routes>
      </BrowserRouter>



      {/* <Info_card/> */}
      {/* <Customer/> */}
      {/* <Background_Img_des/> */}
      {/* <Background_Img/> */}
      {/* <Multiple_Slider/> */}
      {/* <Single_Slider/> */}
      {/* <Navbar /> */}
      {/* <Home/> */}
      {/* <Footer/> */}

    </>
  )
}

export default App
